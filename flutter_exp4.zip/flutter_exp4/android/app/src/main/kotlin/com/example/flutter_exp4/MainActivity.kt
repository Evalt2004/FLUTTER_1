package com.example.flutter_exp4

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
