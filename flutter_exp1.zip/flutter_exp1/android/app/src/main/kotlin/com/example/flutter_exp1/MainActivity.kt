package com.example.flutter_exp1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
