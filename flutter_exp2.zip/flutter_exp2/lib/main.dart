// lib/main.dart
import 'package:flutter/material.dart';

void main() => runApp(const CitiesApp());

class CitiesApp extends StatelessWidget {
  const CitiesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CitiesScreen(),
    );
  }
}

class CitiesScreen extends StatelessWidget {
  const CitiesScreen({super.key});

  final List<Map<String, String>> cities = const [
    {
      'name': 'Vancouver',
      'country': 'Canada',
      'population': '2.4 Million',
      'image':
          'https://images.unsplash.com/photo-1544033527-00a9b7f2bde0?w=800&q=80'
    },
    {
      'name': 'New York',
      'country': 'USA',
      'population': '8.1 Million',
      'image':
          'https://images.unsplash.com/photo-1494972308805-463bc619d34e?w=800&q=80'
    },
    {
      'name': 'Delhi',
      'country': 'India',
      'population': '19 Million',
      'image':
          'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=800&q=80'
    },
    {
      'name': 'London',
      'country': 'Britain',
      'population': '8 Million',
      'image':
          'https://images.unsplash.com/photo-1473959383417-4c9c611d4428?w=800&q=80'
    },
    {
      'name': 'Sydney',
      'country': 'Australia',
      'population': '11 Million',
      'image':
          'https://images.unsplash.com/photo-1506976785307-8732e854ad03?w=800&q=80'
    },
    {
      'name': 'Paris',
      'country': 'France',
      'population': '7 Million',
      'image':
          'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800&q=80'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cities Around the World'),
        backgroundColor: const Color(0xFF007896),
      ),
      body: ListView.builder(
        itemCount: cities.length,
        itemBuilder: (context, index) {
          final city = cities[index];
          return CityCard(
            name: city['name']!,
            country: city['country']!,
            population: city['population']!,
            imageUrl: city['image']!,
          );
        },
      ),
    );
  }
}

class CityCard extends StatelessWidget {
  final String name;
  final String country;
  final String population;
  final String imageUrl;

  const CityCard({
    super.key,
    required this.name,
    required this.country,
    required this.population,
    required this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(10),
              bottomLeft: Radius.circular(10),
            ),
            child: Image.network(
              imageUrl,
              height: 100,
              width: 120,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    country,
                    style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Population: $population',
                    style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
