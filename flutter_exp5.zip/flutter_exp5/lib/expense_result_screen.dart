import 'package:flutter/material.dart';
import 'expense_data_model.dart';

class ExpenseResultScreen extends StatelessWidget {
  const ExpenseResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final expense = ModalRoute.of(context)!.settings.arguments as Expense;
    final balance = expense.income -
        (expense.rentEmi + expense.food + expense.transport + expense.other);

    final isPositive = balance >= 0;
    final color = isPositive ? Colors.green : Colors.red;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Expense Report Screen"),
        backgroundColor: Colors.amber,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            _tile(Icons.money, "Monthly Income", expense.income),
            _tile(Icons.house, "Rent / EMI", expense.rentEmi),
            _tile(Icons.fastfood, "Food Expenses", expense.food),
            _tile(Icons.train, "Transport Expenses", expense.transport),
            _tile(Icons.list_alt, "Other Expenses", expense.other),
            const SizedBox(height: 10),
            Card(
              elevation: 3,
              child: ListTile(
                leading: const Icon(Icons.savings),
                title: const Text("Remaining Balance"),
                subtitle: Text(
                  balance.toStringAsFixed(2),
                  style: TextStyle(color: color, fontSize: 16),
                ),
                trailing: Text(
                  isPositive ? "Saving" : "Overspending!",
                  style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tile(IconData icon, String title, double value) => Card(
        elevation: 2,
        margin: const EdgeInsets.symmetric(vertical: 4),
        child: ListTile(
          leading: Icon(icon),
          title: Text(title),
          subtitle: Text(value.toStringAsFixed(2)),
        ),
      );
}
