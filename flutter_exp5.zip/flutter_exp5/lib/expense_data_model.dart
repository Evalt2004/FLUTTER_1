class Expense {
  final double income;
  final double rentEmi;
  final double food;
  final double transport;
  final double other;

  Expense({
    required this.income,
    required this.rentEmi,
    required this.food,
    required this.transport,
    required this.other,
  });
}
