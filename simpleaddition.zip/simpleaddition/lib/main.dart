import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: AddApp()));

class AddApp extends StatefulWidget {
  const AddApp({super.key});

  @override
  State<AddApp> createState() => _AddAppState();
}

class _AddAppState extends State<AddApp> {
  final a = TextEditingController();
  final b = TextEditingController();
  double sum = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Two Numbers')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(controller: a, keyboardType: TextInputType.number),
            TextField(controller: b, keyboardType: TextInputType.number),
            ElevatedButton(
              onPressed: () => setState(() => sum = double.parse(a.text) + double.parse(b.text)),
              child: const Text('Add'),
            ),
            Text('Result: $sum'),
          ],
        ),
      ),
    );
  }
}