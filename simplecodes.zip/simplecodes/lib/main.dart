// import 'package:flutter/material.dart';

// void main() => runApp(const MaterialApp(home: AddApp()));

// class AddApp extends StatefulWidget {
//   const AddApp({super.key});

//   @override
//   State<AddApp> createState() => _AddAppState();
// }

// class _AddAppState extends State<AddApp> {
//   final a = TextEditingController();
//   final b = TextEditingController();
//   double sum = 0;

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text('Add Two Numbers')),
//       body: Center(
//         child: Column(
//           children: [
//             TextField(controller: a, keyboardType: TextInputType.number),
//             TextField(controller: b, keyboardType: TextInputType.number),
//             ElevatedButton(
//               onPressed: () => setState(() => sum = double.parse(a.text) + double.parse(b.text)),
//               child: const Text('Add'),
//             ),
//             Text('Result: $sum'),
//           ],
//         ),
//       ),
//     );
//   }
// }


// import 'package:flutter/material.dart';

// void main() => runApp(const MaterialApp(home: ListApp()));

// class ListApp extends StatelessWidget {
//   const ListApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.blue, // 🟦 Background color
//       appBar: AppBar(title: const Text('Simple List')),
//       body: ListView(
//         children: const [
//           ListTile(title: Text('Item 1')),
//           ListTile(title: Text('Item 2')),
//           ListTile(title: Text('Item 3')),
//           ListTile(title: Text('Item 4')),
//           ListTile(title: Text('Item 5')),
//         ],
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: ColorListApp()));

class ColorListApp extends StatelessWidget {
  const ColorListApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue, // overall background
      appBar: AppBar(title: const Text('Colorful List')),
      body: ListView(
        children: [
          Container(
            color: Colors.red,
            child: const ListTile(title: Text('Item 1')),
          ),
          Container(
            color: Colors.green,
            child: const ListTile(title: Text('Item 2')),
          ),
          Container(
            color: Colors.yellow,
            child: const ListTile(title: Text('Item 3')),
          ),
          Container(
            color: Colors.orange,
            child: const ListTile(title: Text('Item 4')),
          ),
          Container(
            color: Colors.purple,
            child: const ListTile(title: Text('Item 5')),
          ),
        ],
      ),
    );
  }
}
