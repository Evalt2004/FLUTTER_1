package com.example.simpleaddition

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
