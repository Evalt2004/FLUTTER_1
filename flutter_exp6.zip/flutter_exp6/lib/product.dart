class Product {
  int? id;
  String name;
  int quantity;
  double price;

  Product({
    this.id,
    required this.name,
    required this.quantity,
    required this.price,
  });

  // Safe factory: normalizes types coming from SQLite (int/double/string)
  factory Product.fromRow(Map<String, dynamic> row) {
    // id
    final idVal = row['id'];
    final idParsed = (idVal is int) ? idVal : int.tryParse(idVal?.toString() ?? '');

    // name
    final nameVal = row['name']?.toString() ?? '';

    // quantity
    final qVal = row['quantity'];
    final quantityParsed = (qVal is int)
        ? qVal
        : int.tryParse(qVal?.toString() ?? '') ?? 0;

    // price (SQLite may return int for a REAL that is whole number)
    final pVal = row['price'];
    double priceParsed;
    if (pVal is double) {
      priceParsed = pVal;
    } else if (pVal is int) {
      priceParsed = pVal.toDouble();
    } else {
      priceParsed = double.tryParse(pVal?.toString() ?? '') ?? 0.0;
    }

    return Product(
      id: idParsed,
      name: nameVal,
      quantity: quantityParsed,
      price: priceParsed,
    );
  }

  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      'name': name,
      'quantity': quantity,
      'price': price,
    };
    if (id != null) map['id'] = id;
    return map;
  }
}
