// lib/main.dart
import 'package:flutter/material.dart';

void main() => runApp(const BudgetApp());

class BudgetApp extends StatelessWidget {
  const BudgetApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Budget Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const BudgetScreen(),
    );
  }
}

class BudgetScreen extends StatefulWidget {
  const BudgetScreen({super.key});

  @override
  State<BudgetScreen> createState() => _BudgetScreenState();
}

class _BudgetScreenState extends State<BudgetScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _incomeController = TextEditingController();
  final TextEditingController _rentController = TextEditingController();
  final TextEditingController _foodController = TextEditingController();
  final TextEditingController _transportController = TextEditingController();
  final TextEditingController _otherController = TextEditingController();

  double? _remainingBalance;
  String _message = '';

  @override
  void dispose() {
    _incomeController.dispose();
    _rentController.dispose();
    _foodController.dispose();
    _transportController.dispose();
    _otherController.dispose();
    super.dispose();
  }

  void _calculateBalance() {
    // Validate form fields first
    if (!_formKey.currentState!.validate()) return;

    // parse numbers safely
    final double income = double.tryParse(_incomeController.text.trim()) ?? 0.0;
    final double rent = double.tryParse(_rentController.text.trim()) ?? 0.0;
    final double food = double.tryParse(_foodController.text.trim()) ?? 0.0;
    final double transport =
        double.tryParse(_transportController.text.trim()) ?? 0.0;
    final double other = double.tryParse(_otherController.text.trim()) ?? 0.0;

    final double remaining = income - (rent + food + transport + other);

    setState(() {
      _remainingBalance = remaining;
      if (income <= 0) {
        _message = 'Please enter a positive income.';
      } else if (remaining < 0) {
        _message = 'You are overspending!';
      } else {
        _message = 'You have a positive balance.';
      }
    });
  }

  String? _validateNumber(String? value, {bool allowZero = true}) {
    if (value == null || value.trim().isEmpty) {
      return 'This field cannot be empty';
    }
    final parsed = double.tryParse(value.trim());
    if (parsed == null) return 'Enter a valid number';
    if (!allowZero && parsed <= 0) return 'Enter a number greater than 0';
    return null;
  }

  void _clearAll() {
    _incomeController.clear();
    _rentController.clear();
    _foodController.clear();
    _transportController.clear();
    _otherController.clear();
    setState(() {
      _remainingBalance = null;
      _message = '';
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool overspending =
        (_remainingBalance ?? 0.0) < 0 && (_remainingBalance != null);

    return Scaffold(
      appBar: AppBar(title: const Text('Budget Calculator')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(children: [
          Form(
            key: _formKey,
            child: Column(
              children: [
                _buildNumberField(
                  controller: _incomeController,
                  label: 'Monthly Income',
                  hint: 'e.g. 50000',
                  validator: (v) => _validateNumber(v, allowZero: false),
                ),
                const SizedBox(height: 10),
                _buildNumberField(
                  controller: _rentController,
                  label: 'Rent / EMI',
                  hint: 'e.g. 15000',
                  validator: _validateNumber,
                ),
                const SizedBox(height: 10),
                _buildNumberField(
                  controller: _foodController,
                  label: 'Food Expenses',
                  hint: 'e.g. 6000',
                  validator: _validateNumber,
                ),
                const SizedBox(height: 10),
                _buildNumberField(
                  controller: _transportController,
                  label: 'Transport Expenses',
                  hint: 'e.g. 2000',
                  validator: _validateNumber,
                ),
                const SizedBox(height: 10),
                _buildNumberField(
                  controller: _otherController,
                  label: 'Other Expenses',
                  hint: 'e.g. 3000',
                  validator: _validateNumber,
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _calculateBalance,
                        child: const Text('Calculate Balance'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.grey[300]),
                      onPressed: _clearAll,
                      child: const Text(
                        'Clear',
                        style: TextStyle(color: Colors.black87),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),

          // Result card
          if (_remainingBalance != null)
            Card(
              elevation: 2,
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(14.0),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Remaining Balance',
                              style: TextStyle(
                                  fontSize: 16, color: Colors.grey[800]),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '₹ ${_remainingBalance!.toStringAsFixed(2)}',
                              style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: overspending
                                      ? Colors.red
                                      : Colors.green[700]),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              _message,
                              style: TextStyle(
                                  fontSize: 14,
                                  color: overspending ? Colors.red : Colors.green),
                            ),
                          ]),
                    ),
                    const SizedBox(width: 8),
                    Icon(
                      overspending ? Icons.warning_amber_rounded : Icons.check,
                      color: overspending ? Colors.red : Colors.green,
                      size: 36,
                    ),
                  ],
                ),
              ),
            ),

          // Helpful hint
          const SizedBox(height: 8),
          const Text(
            'Tip: Use the Clear button to reset values.',
            style: TextStyle(color: Colors.black54),
          ),
        ]),
      ),
    );
  }

  Widget _buildNumberField({
    required TextEditingController controller,
    required String label,
    String? hint,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType:
          const TextInputType.numberWithOptions(signed: false, decimal: true),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: const OutlineInputBorder(),
        contentPadding:
            const EdgeInsets.symmetric(vertical: 12.0, horizontal: 12.0),
      ),
      validator: validator ?? _validateNumber,
    );
  }
}
