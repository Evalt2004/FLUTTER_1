import 'package:flutter/material.dart';
import 'expense_data_model.dart';

class ExpenseScreen extends StatefulWidget {
  const ExpenseScreen({super.key});
  @override
  State<ExpenseScreen> createState() => _ExpenseScreenState();
}

class _ExpenseScreenState extends State<ExpenseScreen> {
  final _formKey = GlobalKey<FormState>();
  final income = TextEditingController();
  final rent = TextEditingController();
  final food = TextEditingController();
  final transport = TextEditingController();
  final other = TextEditingController();

  void _submit() {
    if (!_formKey.currentState!.validate()) return;

    final expense = Expense(
      income: double.parse(income.text),
      rentEmi: double.parse(rent.text),
      food: double.parse(food.text),
      transport: double.parse(transport.text),
      other: double.parse(other.text),
    );

    Navigator.pushNamed(context, '/result', arguments: expense);
  }

  String? _validate(String? v) {
    if (v == null || v.trim().isEmpty) return 'Enter value';
    final n = double.tryParse(v);
    if (n == null || n < 0) return 'Enter a valid number';
    return null;
  }

  Widget _field(TextEditingController c, String label) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: TextFormField(
          controller: c,
          validator: _validate,
          keyboardType:
              const TextInputType.numberWithOptions(decimal: true, signed: false),
          decoration: InputDecoration(
            labelText: label,
            border: const OutlineInputBorder(),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Expense Details Screen"),
        backgroundColor: Colors.amber,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              _field(income, 'Monthly Income'),
              _field(rent, 'Rent / EMI'),
              _field(food, 'Food Expenses'),
              _field(transport, 'Transport Expenses'),
              _field(other, 'Other Expenses'),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submit,
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green, foregroundColor: Colors.white),
                child: const Text("Submit Details"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
