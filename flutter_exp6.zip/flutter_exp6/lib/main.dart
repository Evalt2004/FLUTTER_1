import 'package:flutter/material.dart';
import 'databasehelper.dart';
import 'product.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _quantityController = TextEditingController();
  final _priceController = TextEditingController();
  List<Product> _products = [];

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    try {
      final list = await DatabaseHelper.instance.readAllProducts();
      setState(() => _products = list);
      debugPrint('Loaded ${list.length} products from DB');
    } catch (e, st) {
      debugPrint('Error loading products: $e\n$st');
    }
  }

  double getTotalStockValue() {
    return _products.fold(0.0, (sum, p) => sum + (p.quantity * p.price));
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Product Inventory Tracker",
      home: Scaffold(
        backgroundColor: const Color.fromARGB(255, 243, 242, 225),
        appBar: AppBar(
          title: const Text("Product Inventory Tracker"),
          backgroundColor: const Color.fromARGB(255, 255, 175, 2),
        ),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: "Enter product name",
                    border: OutlineInputBorder(),
                  ),
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Enter name' : null,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _quantityController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: "Enter product quantity",
                    border: OutlineInputBorder(),
                  ),
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Enter quantity' : null,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _priceController,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                    labelText: "Enter product price",
                    border: OutlineInputBorder(),
                  ),
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Enter price' : null,
                ),
                const SizedBox(height: 12),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 255, 132, 31),
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 24, vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30)),
                  ),
                  onPressed: () async {
                    if (!_formKey.currentState!.validate()) return;
                    try {
                      final name = _nameController.text.trim();
                      final quantity =
                          int.tryParse(_quantityController.text.trim()) ?? 0;
                      final price = double.tryParse(_priceController.text.trim()) ?? 0.0;

                      final product =
                          Product(name: name, quantity: quantity, price: price);

                      final id = await DatabaseHelper.instance.insertProduct(product);
                      debugPrint('Inserted product id: $id');

                      await _loadProducts();

                      ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Product saved')));

                      _nameController.clear();
                      _quantityController.clear();
                      _priceController.clear();
                    } catch (e, st) {
                      debugPrint('Add product failed: $e\n$st');
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text('Failed to add product: $e')));
                    }
                  },
                  child: const Text('Add Product'),
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: _products.isEmpty
                      ? const Center(child: Text("No products found"))
                      : ListView.builder(
                          itemCount: _products.length,
                          itemBuilder: (context, idx) {
                            final p = _products[idx];
                            return Card(
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor:
                                      p.quantity < 5 ? Colors.red : Colors.blue,
                                  child: Text(p.name.isNotEmpty
                                      ? p.name[0].toUpperCase()
                                      : '?'),
                                ),
                                title: Text(p.name),
                                subtitle: Text(
                                    'Quantity: ${p.quantity}  |  Price: ${p.price.toStringAsFixed(2)}'),
                                trailing: p.quantity < 5
                                    ? const Text('Low Stock',
                                        style: TextStyle(color: Colors.red))
                                    : null,
                              ),
                            );
                          },
                        ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    'Total Stock Value: ${getTotalStockValue().toStringAsFixed(2)}',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                )
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
