package com.example.flutter_exp5

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
