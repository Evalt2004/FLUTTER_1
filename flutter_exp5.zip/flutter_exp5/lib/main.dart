import 'package:flutter/material.dart';
import 'expense_details_screen.dart';
import 'expense_result_screen.dart';

void main() {
  runApp(MaterialApp(
    title: "Expense Navigator Demo",
    debugShowCheckedModeBanner: false,
    initialRoute: '/',
    routes: {
      '/': (context) => const ExpenseScreen(),
      '/result': (context) => const ExpenseResultScreen(),
    },
  ));
}
