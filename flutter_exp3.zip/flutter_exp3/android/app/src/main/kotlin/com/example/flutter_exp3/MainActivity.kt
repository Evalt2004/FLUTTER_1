package com.example.flutter_exp3

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
