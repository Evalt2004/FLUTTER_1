import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(home: SimpleCalculator()));

class SimpleCalculator extends StatefulWidget {
  const SimpleCalculator({super.key});

  @override
  State<SimpleCalculator> createState() => _SimpleCalculatorState();
}

class _SimpleCalculatorState extends State<SimpleCalculator> {
  final a = TextEditingController();
  final b = TextEditingController();
  double result = 0;

  void calculate(String op) {
    final num1 = double.tryParse(a.text) ?? 0;
    final num2 = double.tryParse(b.text) ?? 0;

    setState(() {
      switch (op) {
        case '+':
          result = num1 + num2;
          break;
        case '-':
          result = num1 - num2;
          break;
        case '×':
          result = num1 * num2;
          break;
        case '÷':
          result = num2 != 0 ? num1 / num2 : double.nan;
          break;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Simple Calculator')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: a,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Number 1'),
            ),
            TextField(
              controller: b,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Number 2'),
            ),
            const SizedBox(height: 20),
            Wrap(
              spacing: 10,
              children: [
                ElevatedButton(onPressed: () => calculate('+'), child: const Text('+')),
                ElevatedButton(onPressed: () => calculate('-'), child: const Text('-')),
                ElevatedButton(onPressed: () => calculate('×'), child: const Text('×')),
                ElevatedButton(onPressed: () => calculate('÷'), child: const Text('÷')),
              ],
            ),
            const SizedBox(height: 20),
            Text('Result: $result', style: const TextStyle(fontSize: 20)),
          ],
        ),
      ),
    );
  }
}
