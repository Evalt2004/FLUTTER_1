package com.example.flutter_exp6

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
