package com.example.add

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
