import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'product.dart';
import 'package:flutter/foundation.dart';

class DatabaseHelper {
  static Database? _database;
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();
  DatabaseHelper._privateConstructor();

  Future<Database> get database async {
    if (_database != null) return _database!;
    Directory dir = await getApplicationDocumentsDirectory();
    final path = join(dir.path, 'products.db');
    debugPrint('Opening DB at $path');
    _database = await openDatabase(path, version: 1, onCreate: _onCreate);
    return _database!;
  }

  Future<void> _onCreate(Database db, int version) async {
    debugPrint('Creating products table');
    await db.execute('''
      CREATE TABLE products(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        price REAL NOT NULL
      )
    ''');
  }

  Future<int> insertProduct(Product p) async {
    final db = await database;
    debugPrint('Insert: ${p.name}, ${p.quantity}, ${p.price}');
    final id = await db.insert('products', p.toMap());
    debugPrint('Inserted id: $id');
    return id;
  }

  Future<List<Product>> readAllProducts() async {
    final db = await database;
    final rows = await db.query('products', orderBy: 'id DESC');
    debugPrint('readAllProducts returned ${rows.length} rows');
    return rows.map((r) => Product.fromRow(r)).toList();
  }

  Future<int> resetProducts() async {
    final db = await database;
    return await db.delete('products');
  }
}
