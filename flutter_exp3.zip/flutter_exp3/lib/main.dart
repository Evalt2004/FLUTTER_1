// lib/main.dart
import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MobileListScreen(),
    );
  }
}

class MobileListScreen extends StatefulWidget {
  const MobileListScreen({super.key});
  @override
  State<MobileListScreen> createState() => _MobileListScreenState();
}

class _MobileListScreenState extends State<MobileListScreen> {
  // initial list of mobiles
  final List<Map<String, dynamic>> _mobiles = [
    {
      "title": "iPhone 14 Pro",
      "subtitle": "Apple flagship",
      "price": 129999,
      "image":
          "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-14-pro-hero"
    },
    {
      "title": "Samsung Galaxy S23 Ultra",
      "subtitle": "Best camera phone",
      "price": 124999,
      "image":
          "https://images.samsung.com/is/image/samsung/assets/levant/galaxy-s23-ultra/gallery/galaxy-s23-ultra-01.jpg"
    },
    {
      "title": "OnePlus 11 5G",
      "subtitle": "Premium flagship killer",
      "price": 61999,
      "image":
          "https://image01.oneplus.net/ebp/202301/05/1-m00-3a-3b-rb8bwmqekjyaaxybaaffmyu5edk697.png"
    },
    {
      "title": "Google Pixel 7 Pro",
      "subtitle": "Best stock Android",
      "price": 84999,
      "image":
          "https://lh3.googleusercontent.com/d/1j8D9lOqIr2-kI9ySn_jFF3RYwGBI5ODp=w1000"
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mobile Store'),
        backgroundColor: Colors.blueGrey,
      ),
      body: _mobiles.isEmpty
          ? const Center(
              child: Text('No items available',
                  style: TextStyle(fontSize: 18, color: Colors.grey)))
          : ListView.separated(
              padding: const EdgeInsets.all(8),
              itemCount: _mobiles.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (context, index) {
                final mobile = _mobiles[index];
                return ListTile(
                  onTap: () => _showDetailsDialog(context, mobile),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: Image.network(
                      mobile["image"],
                      width: 60,
                      height: 60,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) => const Icon(
                        Icons.broken_image,
                        size: 48,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                  title: Text(
                    mobile["title"],
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(mobile["subtitle"]),
                  trailing: SizedBox(
                    width: 110,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "₹${mobile["price"]}",
                          style: const TextStyle(
                              color: Colors.blue, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        ElevatedButton(
                          onPressed: () => _buyItem(context, index),
                          child: const Text("Buy", style: TextStyle(fontSize: 12)),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  void _buyItem(BuildContext context, int index) {
    final title = _mobiles[index]['title'];
    setState(() {
      _mobiles.removeAt(index);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$title bought successfully!')),
    );
  }

  void _showDetailsDialog(BuildContext context, Map<String, dynamic> mobile) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(mobile['title']),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 120,
              child: Image.network(
                mobile['image'],
                fit: BoxFit.contain,
                errorBuilder: (c, e, s) => const Icon(Icons.broken_image, size: 56),
              ),
            ),
            const SizedBox(height: 12),
            Text(mobile['subtitle']),
            const SizedBox(height: 6),
            Text('Price: ₹${mobile['price']}',
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
        ],
      ),
    );
  }
}
